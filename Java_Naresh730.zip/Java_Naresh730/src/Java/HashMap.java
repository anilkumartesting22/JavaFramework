package Java;

public class HashMap {

	public static void main(String[] args) {
		HashMap emp=new HashMap();

	}

}
