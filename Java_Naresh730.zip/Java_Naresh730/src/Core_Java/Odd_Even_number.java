package Core_Java;

public class Odd_Even_number {

	public static void main(String[] args) {
	 int[] a= {1,2,3,4,5,6,7,8};
	 for(int c:a)
	 {
		 if(c%2!=0)
		 {
			 System.out.println(c);
		 }
	 }

	}

}
