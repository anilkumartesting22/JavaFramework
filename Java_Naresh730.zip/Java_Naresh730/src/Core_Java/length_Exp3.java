package Core_Java;

public class length_Exp3 {

	public static void main(String[] args) {
		String harsh="Selenium easy tool";
		int data=harsh.length();
		System.out.println(data);

	}

}
