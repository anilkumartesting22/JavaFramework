package Core_Java;

public class Array1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][]a ={{5,6,7},
			     {9,10,11},
				 {12,34,56}
		};
		
		}

	}


