package Core_Java;

public class Continute {

	public static void main(String[] args) {
		for(int i=1;i<=9;i++) 
		{
			if(i==4)
			{
				continue;
			}
			System.out.println(i);
		}
		System.out.println("I am out side of loop");
		

	}

}
