package Core_Java;

public class AdditionExp2 {
	String name="Selenium";
	public void Add()
	{
		int a=34;
		int b=45;
		int c=a+b;
		System.out.println("This is Addition:"+c);
	}
	public void Sub()
	{
	 int v=56;
	 int u=23;
	 int x=v-u;
	 System.out.println("This is Subtraction:"+x);
	}
	public void Multi()
	{
		int z=67;
		int y=12;
		int i=z*y;
		System.out.println("This is multi:"+i);
	}
	public static void Div()
	{
		int r=55;
		int h=5;
		int j=r/h;
		System.out.println("This is division:"+j);
	
	}

	public static void main(String[] args) {
		
		
		//obj.Div();
		//obj.Add();
		AdditionExp2.Div();

	}

}
