package Core_Java;

public class Multilevel_Inheritance_ClassA {
	public void Add(int a,int b)
	{
		int c=a+b;
		System.out.println(c);
	}
	public void Mul()
	{
		int v=23*12;
		System.out.println(v);
	}
	public void Div(int l,int h)
	{
		int f=l/h;
		System.out.println(f);
		
	}
	public int Sub()
	{
		int g=23-10;
		return g;
		
		
	}
	

}
