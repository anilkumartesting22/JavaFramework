package Core_Java;

public class HashMap {

	public static void main(String[] args) {
		//syntax of HashMap
	//	HashMap<Integer,String>emp=new HashMap<Integer,String>();
	}

}
