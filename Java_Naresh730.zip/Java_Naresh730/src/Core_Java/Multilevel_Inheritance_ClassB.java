package Core_Java;

public class Multilevel_Inheritance_ClassB extends Multilevel_Inheritance_ClassA {
    String name="Selenium is very easy tool";
    public void Div1()
    {
    	int x=55/10;
    	System.out.println(x);
    }
	public static void main(String[] args) {
		Multilevel_Inheritance_ClassB obj=new Multilevel_Inheritance_ClassB();
		obj.Add(23, 56);
		System.out.println(obj.Sub());
		obj.Div1();

	}

}
