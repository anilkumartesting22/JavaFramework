package Core_Java;

public class MethodOverloding_Exp1 {
	public void Selenium(int a,int b)
	{
		int c= a+b;
		System.out.println(c);
	}
	public void Selenium(int age, String name)
	{
		System.out.println(name);
		System.out.println(age);
	}
	public void Selenium(String name3, String name5, int age2)
	{
	 int a=22+32;
		
		System.out.println(name3);
		System.out.println(name5);
		System.out.println(age2);
	}

	public static void main(String[] args) {
		MethodOverloding_Exp1 obj=new MethodOverloding_Exp1();
		obj.Selenium(34, 23);
		System.out.println("===========");
		obj.Selenium(34, "Java");
		System.out.println("===========");
		obj.Selenium("python", "Ruby", 25);

	}

}
