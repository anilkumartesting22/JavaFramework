package Core_Java;

import java.util.Scanner;

public class Scanner_Class {

	public static void main(String[] args) {
		//syntax of the scanner class
		Scanner sc=new Scanner(System.in);
		System.out.println("Mr.Anil please enter first value");
		int a=sc.nextInt();
		System.out.println("Mr.Anil please provide Second value");
		int b=sc.nextInt();
		int c=a+b;
		System.out.println("The value is:"+c);

	}

}
