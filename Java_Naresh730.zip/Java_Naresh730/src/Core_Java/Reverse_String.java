package Core_Java;

public class Reverse_String {

	public static void main(String[] args) {
		String name="Selenium";
		String rev="";
		int len=name.length();//8
		for(int i=len-1;i>=0;i--)   //mu
		{
			rev=rev+name.charAt(i);
		}
		System.out.println("The namae of reverse String:"+rev);
}
}
