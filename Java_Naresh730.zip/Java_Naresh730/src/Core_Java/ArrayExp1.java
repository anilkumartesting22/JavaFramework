package Core_Java;

public class ArrayExp1 {

	public static void main(String[] args) {
		//syntax of the array
		//store the values
		int[] a=new int[4];
		a[0]=76;
		a[1]=56;
		a[2]=67;
		a[3]=78;
		//a[4]=89;
		for(int i=0;i<4;i++)
		{
			System.out.println("The values is:"+a[i]);
		}

	}

}
