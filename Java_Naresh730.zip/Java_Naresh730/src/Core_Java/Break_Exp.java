package Core_Java;

public class Break_Exp {

	public static void main(String[] args) {
		//1-10 test cases
		//1-5 need to execute
		
		for(int i=1;i<=9;i++)//this is Anil
		{
			System.out.println(i);
			if(i==5)//bhart need to 5
			{
				break;
			}
		}
		System.out.println("I am out side of loop");

	}

}
