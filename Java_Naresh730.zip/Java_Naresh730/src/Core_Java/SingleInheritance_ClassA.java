package Core_Java;

public class SingleInheritance_ClassA {
	public void Add()
	{
		int a=23+45;
		System.out.println(a);
	}
	public void Mul()
	{
		int b=34*12;
		System.out.println(b);
	}
	public void Sub(int j,int p)
	{
		int d=j-p;
		System.out.println(d);
	}
	public void Div()
	{
		int s=35/5;
		System.out.println(s);
	}

}
