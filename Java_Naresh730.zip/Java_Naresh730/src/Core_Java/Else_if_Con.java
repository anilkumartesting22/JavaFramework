package Core_Java;

public class Else_if_Con {

	public static void main(String[] args) {
		int a=56+12;
		if(a>134)
		{
			System.out.println("Grade A");
		}
		else if(a<123)
		{
			System.out.println("Grade B");
		}
		else if(a>124)
		{
			System.out.println("Grade C");
		}
		else if(a<897)
		{
			System.out.println("Grade D");
		}
		else 
		{
			System.out.println("The Test case is faild");
		}

	}

}
