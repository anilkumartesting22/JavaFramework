package Core_Java;

public class Hirarchical_ClassB extends Hirarchical_ClassA {

	public static void main(String[] args) {
		Hirarchical_ClassB obj=new Hirarchical_ClassB();
		obj.Add();
		obj.sub();

	}

}
