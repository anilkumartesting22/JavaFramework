package Core_Java;

public class AdditionExp1 {
  
	public static void main(String[] args) {
		int a=56;
		int b=78;
		int c=a+b;
		System.out.println("This is Addition:"+c);
		int d=78;
		int e=56;
		int f=d*e;
		System.out.println("This is Multiplecation:"+f);
		//division
		int x=35;
		int y=5;
		int z=x/y;
		System.out.println("This is Division:"+z);
		
		
		
		
		

	}

}
