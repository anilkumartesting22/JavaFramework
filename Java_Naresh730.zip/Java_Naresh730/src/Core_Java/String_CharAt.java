package Core_Java;

public class String_CharAt {

	public static void main(String[] args) {
		String name="Hyderabad metro city";
		int cha=name.length();
		char con=name.charAt(6);
		System.out.println(con);
		System.out.println("=======");
		char con1=name.charAt(0);
		System.out.println(con1);
		System.out.println("==========");
		for(int i=0;i<name.length();i++)
		{
			char na=name.charAt(i);
			System.out.print(na);
		}
		
		

	}

}
