package Core_Java;

public class String_UpperCase {

	public static void main(String[] args) {
		String name="AuToMation SeleNiuM";
		String con=name.toLowerCase();
		System.out.println(con);
		String name2="without PrActIce iT's difFIcult";
		String con2=name2.toUpperCase();
		System.out.println(con2);

	}

}
