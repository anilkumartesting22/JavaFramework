package Core_Java;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Read_data_from_Text {

	public static void main(String[] args) throws IOException  {
		FileReader file=new FileReader("C:\\Users\\DELL\\Desktop\\Naresh.txt");
		BufferedReader br=new BufferedReader(file);
		String str;
		while((str=br.readLine())!= null)
{
   System.out.println(str);
	}
		
	}
}


