package Core_Java;

class Keka
{
	//String name="Selenium tool";
   Keka()
  {
	  
	  System.out.println("Constractoe is class name");
  }
}
//=======================================================
class Selenium extends Keka
{
	//String name="Easy Tool";
	 Selenium()
	{
		//super.java();------>Immidiate methods
		//System.out.println(super.name);----->immeidiate Instance method
	    super();//----------->Constractor method
		System.out.println("Return type doesn't accept");
		//super();========>No need to provide 
		
	}
	
}
//========================================================

public class Super_Exp1 {

	public static void main(String[] args) {
		Selenium obj=new Selenium();
	//	obj.java();
	
		

	}

}
