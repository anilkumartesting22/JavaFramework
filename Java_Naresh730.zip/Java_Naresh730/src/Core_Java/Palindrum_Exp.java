package Core_Java;

import java.util.Scanner;

public class Palindrum_Exp {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value");
		int num=sc.nextInt();
		int Anil=num;
		int rev=0;
		while(num!=0)
		{
			rev=rev*10+num%10;//0*10+141%10
			num=num/10;//141=141
			
		}
	//	System.out.println(rev);
		if(Anil==rev)
		{
			System.out.println(Anil+" This is palindrum");
		}
		else
		{
			System.out.println(Anil+" This is not a palindrum");
		}

	}
	

}
