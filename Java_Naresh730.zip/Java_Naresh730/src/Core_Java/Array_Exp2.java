package Core_Java;

public class Array_Exp2 {

	public static void main(String[] args) {
		//syntax of Array
		String[] data=new String[4];
		data[0]="selenium";
		data[1]="Java";
		data[2]="Python";
		data[3]="Ruby";
		//data[4]="Tablue";
		System.out.println("The array name is:"+data[3]);

	}

}
