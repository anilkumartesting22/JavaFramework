package Core_Java;
//this accept the java
interface ClassA {

}
interface ClassB
{
	
}
interface ClassC extends ClassA,ClassB
{
	
}
//this is not accept jova
