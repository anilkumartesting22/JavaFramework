package Core_Java;

public class AddExp3 {
	public void Add(int a,int b)
	{
		int c=a+b;
		System.out.println("This is addition:"+c);
		
	}
	public void Div(int s,int h)
	{
		int x=s/h;
		System.out.println("This is Division:"+x);
	}
	public void Sub(int f,int j)
	{
		int g=f-j;
		System.out.println("This is Sub:"+g);
	}

	public static void main(String[] args) {
		AddExp3 obj=new AddExp3();
		obj.Add(125, 345);
		obj.Div(125, 5);
		obj.Sub(123, 341);

	}

}
