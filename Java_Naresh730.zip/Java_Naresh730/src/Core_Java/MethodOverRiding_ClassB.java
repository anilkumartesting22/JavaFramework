package Core_Java;

public class MethodOverRiding_ClassB extends MethodOverRiding_ClassA{
	public void Automation(String name6,String name8)
	{
		System.out.println(name6);
		System.out.println(name8);
	}
	public void Automation(int age2, String name7)
	{
		System.out.println(age2);
		System.out.println(name7);
	}
	public void Automation(int age7,String name11,String name12)
	{
		System.out.println(name11);
		System.out.println(name12);
		System.out.println(age7);
		
	}

	public static void main(String[] args) {
		MethodOverRiding_ClassB obj=new MethodOverRiding_ClassB();
		obj.Automation(12, "Java");
		System.out.println("=======");
		obj.Automation(" python", 13);
		System.out.println("=======");
		obj.Automation("Ruby", "Talend");
		System.out.println("=======");
		obj.Automation(23, "RPA", "Deveops");
				
		

	}

}
