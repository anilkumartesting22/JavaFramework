package Core_Java;

public class String_IsEmpty {

	public static void main(String[] args) {
		String n1="";
		String n2="";
		boolean B1=n1.isEmpty();
		System.out.println(B1);
		boolean B2=n2.isEmpty();
		System.out.println(B2);

	}

}
