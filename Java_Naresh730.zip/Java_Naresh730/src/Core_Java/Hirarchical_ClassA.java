package Core_Java;

public class Hirarchical_ClassA {
	public void Add()
	{
		int a=12+56;
		System.out.println("This is addition:"+a);
	}
	public void Div(int d,int s)
	{
		int y=d/s;
		System.out.println(y);
	}
	public int mul()
	{
		int f=23*12;
		return f;
		
	}
	public void sub()
	{
		int w=12-10;
		System.out.println(w);
	}

}
