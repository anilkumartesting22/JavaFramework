package Core_Java;

public class Odd_Even_Exp2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
