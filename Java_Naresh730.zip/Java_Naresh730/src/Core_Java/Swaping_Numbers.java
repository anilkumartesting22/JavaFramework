package Core_Java;

public class Swaping_Numbers {

	public static void main(String[] args) {
		int a=12, b=23;
		System.out.println("Before swaping..."+ a +"  "+b);
//		int l=a;
//		a=b;
//		b=l;
		a=a+b;//12+23=35
		b=a-b;//35-23=12
		a=a-b;//35-12=23
		System.out.println("After swaping...."+ a +" "+b);

	}

}
