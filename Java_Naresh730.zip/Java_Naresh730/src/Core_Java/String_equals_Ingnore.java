package Core_Java;

public class String_equals_Ingnore {

	public static void main(String[] args) {
		String name="Selenium";
		String name2="selenIum";
		if(name.equals(name2))
		{
			System.out.println("Testcase pass");
		}
		else
		{
			System.out.println("Testcase faild");
		}
		String name3="AutomATiOn";
		String name4="aUtoMation";
		if(name3.equalsIgnoreCase(name4))
		{
			System.out.println("The test case pass");
		}
		else
		{
			System.out.println("The test case is faild");
		}
	}

}
