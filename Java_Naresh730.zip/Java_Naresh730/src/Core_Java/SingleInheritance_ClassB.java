package Core_Java;

public class SingleInheritance_ClassB extends SingleInheritance_ClassA{

	public static void main(String[] args) {
		SingleInheritance_ClassB obj=new SingleInheritance_ClassB();
		obj.Add();
		obj.Div();
		obj.Mul();
		obj.Sub(23, 12);
		
	}

}
