package Core_Java;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Bubble_Sorting {

	public static void main(String[] args) {
		int[] a= {2,4,6,7,1,8,9,5,3};
		System.out.println("Before bubble sorting..."+Arrays.toString(a));
		int n=a.length;
		for(int i=0; i<n-1;i++)//number of pass
		{
			for(int j=0;j<n-1;j++)// iterations
			{
				if(a[j]>a[j+1])
				{
					int temp=a[j];
					a[j]=a[j+1]; 
					a[j+1]=temp;
				}
			}
		}
		System.out.println("After Bubble sorting..."+Arrays.toString(a));

	}

}
