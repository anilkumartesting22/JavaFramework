package Core_Java;

public class length_exp4 {

	public static void main(String[] args) {
		String[] data= {"Automation","Selenium","Java","Ruby"};
		int con=data.length;
		System.out.println(con);
		System.out.println(data[2].length());
		

	}

}
