package Core_Java;

public class Identify_primenumber {

	public static void main(String[] args) {
		int num=301;
		int count=0;
		for(int i=1;i<=num;i++)
		{
			if(num%i==0)
			{
				count++;
			}
		}
		if(count==2)
		{
			System.out.println("this is Prime");
		}
		else
		{
			System.out.println("this is not a prime");
		}
	}

}
