package Core_Java;

public class String_Starts_with2 {

	public static void main(String[] args) {
		String name="Selenium";
		boolean con=name.startsWith("i", 5);
		if(con)
		{
			System.out.println("Pass");
		}
		else
		{
			System.out.println("fail");
		}
		

	}

}
