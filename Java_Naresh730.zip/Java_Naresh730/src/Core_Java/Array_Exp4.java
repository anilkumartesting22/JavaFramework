package Core_Java;

public class Array_Exp4 {

	public static void main(String[] args) {
		//syntax of the Three Dimension Array
		int[][] a=new int[3][3];
		a[0][0]=56;
		a[0][1]=78;
		a[0][2]=23;
		a[1][0]=90;
		a[1][1]=80;
		for(int i=0;i<2;i++)

		{
			for(int j=0;j<2;j++)
			{
				System.out.println(a[i][j]);
			}
		}
		
		
		

	}

}
