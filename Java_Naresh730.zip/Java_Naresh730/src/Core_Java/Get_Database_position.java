package Core_Java;

public class Get_Database_position {

	public static void main(String[] args) {
		int[] a= {12,34,56,78,90,25,67};
		for(int i=0;i<a.length;i++)
		{
			System.out.println("The position of valuse" +i +"is:"+a[i]);
		}
	}

}
