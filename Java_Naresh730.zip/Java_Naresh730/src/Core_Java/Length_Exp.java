package Core_Java;

public class Length_Exp {

	public static void main(String[] args) {
		int[] a= {23,45,67,89,34,51};
		System.out.println(a.length);//get the complete length
		System.out.println(a[3]);//get the particuler position

	}

}
