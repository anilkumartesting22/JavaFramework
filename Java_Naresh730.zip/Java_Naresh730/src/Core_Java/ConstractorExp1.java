package Core_Java;

public class ConstractorExp1 {
	public ConstractorExp1()
	{
		
	}
	public void Hi() 
	{
		System.out.println("hello");
	}

	public static void main(String[] args) {
		ConstractorExp1 obj=new ConstractorExp1();
		obj.Hi();

	}

}
