package Core_Java;

public class Encpaslation_Exp1 {
private	String name;
private	int age;
private	int batch;
public String getname()
{
	return name;
}
public void Setname(String name2)
{
	this.name=name2;
}
public int getage()
{
	return age;
}
public void Setage(int age2)
{
	this.age=age2;
}
public int getbatch()
{
	return batch;
}
public void Setbatch(int batch2)
{
	this.batch=batch2;
}

	public static void main(String[] args) {
		Encpaslation_Exp1 obj=new Encpaslation_Exp1();
		obj.Setname("Shushma");
		obj.Setage(27);
		obj.Setbatch(2015);
		System.out.println(obj.getname());
		System.out.println(obj.getage());
		System.out.println(obj.getbatch());
		
	}

}
