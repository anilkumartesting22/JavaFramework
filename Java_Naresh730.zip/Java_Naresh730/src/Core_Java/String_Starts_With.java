package Core_Java;

public class String_Starts_With {

	public static void main(String[] args) {
	 //startswith
		String slogan="Jana gana mana";
		boolean con=slogan.startsWith("Jana");
		if(con)
		{
			System.out.println("Starts with Jana");
		}
		else
		{
			System.out.println("test case fail");
		}
		boolean con1=slogan.endsWith("gana");
		if(con1)
		{
			System.out.println("Ends with gana");
		}
		else
		{
			System.out.println("Testcase fail");
		}
				
	}

}
