package Core_Java;

public class If_Con {

	public static void main(String[] args) {
	     int a=34+67;
	     if(a<12)
	     {
	    	 System.out.println("Grade A");
	     }
	     else
	     {
	    	 System.out.println("The test case faild");
	     }
	}

}
