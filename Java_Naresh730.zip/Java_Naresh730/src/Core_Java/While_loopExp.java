package Core_Java;

public class While_loopExp {

	public static void main(String[] args) {
		int i=0;
		while(i<=9)
		{
			
			System.out.println(i);
			i++;
			
		}

	}

}
