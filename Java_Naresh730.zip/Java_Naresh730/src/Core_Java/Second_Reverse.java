package Core_Java;

import java.util.Scanner;

public class Second_Reverse {

	public static void main(String[] args) {
		//scan the data from console
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first name,second name,last name");
		String fullname=sc.nextLine();
		
		//Split
		String[] full_nameArray=fullname.split("\\s");
		
		//parameters
		String first= full_nameArray[0];
		String second= full_nameArray[1];
		String third= full_nameArray[2];
		
		//String reverse
		String second_reverse=new StringBuilder(second).reverse().toString();
		
		//print
		System.out.println("the first name:"+first);
		System.out.println(("the second(reverse):"+second_reverse));
		System.out.println("the third name:"+third);
		
		
		
		

	}

}
