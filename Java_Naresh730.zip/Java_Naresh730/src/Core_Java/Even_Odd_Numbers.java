package Core_Java;

public class Even_Odd_Numbers {

	public static void main(String[] args) {
		int[] a= {1,2,3,4,5,6,7,8,9,10};
		System.out.println("Evean numbers");
		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2==0)
			{
				System.out.println(a[i]);
			}
			else
			{
				System.out.println("The test case faild");
			}
		}
		System.out.println("Odd numbers");
		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2!=0)
				
			{
				System.out.println(a[i]);
			}
			else
			{
				System.out.println("The test case2 faild");
			}
		}
	}

}
