package Core_Java;

public class For_each_Exp {

	public static void main(String[] args) {
		int[] a= {23,56,87,12,78,90};
		//System.out.println(a[4]);
		//for each loop
		for(int c:a)
		{
			System.out.println(c);
		}

	}

}
