package Core_Java;
 abstract class Automation
 {
	 abstract void Selenium();
	 abstract void python();
 }
 class java extends Automation
 {
	 public void Selenium()
	 {
		 System.out.println("This is Selenium");
	 }
	 public void python()
	 {
		 System.out.println("Sele:without practice it's difficult");
	 }
 }
public class Abstract_Exp {

	public static void main(String[] args) {
		java obj=new java();
		obj.Selenium();
		obj.python();

	}

}
