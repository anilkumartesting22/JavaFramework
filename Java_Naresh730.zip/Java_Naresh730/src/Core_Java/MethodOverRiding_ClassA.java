package Core_Java;

public class MethodOverRiding_ClassA {
	public void Automation(String name,int age)
	{
		System.out.println(name);
		System.out.println(age);
	}
	public void Automation(int age,String name4,String name1)
	{
		System.out.println(age);
		System.out.println(name4);
		 System.out.println(name1);
	}
	public void Automation(String name2,String name3)
	{
		System.out.println(name2);
		System.out.println(name3);
	}

}
