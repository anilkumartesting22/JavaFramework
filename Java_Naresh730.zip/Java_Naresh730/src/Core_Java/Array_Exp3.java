package Core_Java;

public class Array_Exp3 {

	public static void main(String[] args) {
		//syntax of the two dimensional array
		int[][] data=new int[2][2];
		data[0][0]=65;
		data[0][1]=98;
		data[1][0]=12;
		data[1][1]=34;
		System.out.println("The value is:"+data[0][1]);

	}

}
