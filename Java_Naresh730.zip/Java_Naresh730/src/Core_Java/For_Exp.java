package Core_Java;

public class For_Exp {

	public static void main(String[] args) {
		//1-10
//		System.out.println(1);
//		System.out.println(2);
//		System.out.println(3);
//		System.out.println(4);
//		System.out.println(5);
//		System.out.println(6);
//		System.out.println(7);
//		System.out.println(8);
//		System.out.println(9);
		for(int i=0;i<=9;i++)
		{
			System.out.println(i);
		}
	}

}
