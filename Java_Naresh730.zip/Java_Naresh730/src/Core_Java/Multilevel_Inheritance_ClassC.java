package Core_Java;

public class Multilevel_Inheritance_ClassC extends Multilevel_Inheritance_ClassB {
    String slogan="With out Practice it's very difficult";
	public static void main(String[] args) {
		Multilevel_Inheritance_ClassC obj2=new Multilevel_Inheritance_ClassC();
        obj2.Div(35, 5);
        obj2.Mul();
        System.out.println(obj2.name);
        System.out.println(obj2.slogan);
	}

}
