package Core_Java;

public class Hirarchical_ClassC extends Hirarchical_ClassA{

	public static void main(String[] args) {
		Hirarchical_ClassC obj3=new Hirarchical_ClassC();
		obj3.Div(100, 10);
		System.out.println(obj3.mul());

	}

}
