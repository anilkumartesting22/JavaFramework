package Core_Java;

public class For_eachExp {

	public static void main(String[] args) {
	  String[] data= {"Selenium","Java","Python","Ruby"};
	  for(String con:data)
	  {
		  System.out.println(con);
	  }

	}

}
