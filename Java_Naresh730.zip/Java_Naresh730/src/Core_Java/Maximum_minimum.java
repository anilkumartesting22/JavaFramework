package Core_Java;

public class Maximum_minimum {

	public static void main(String[] args) {
		int[] a= {12,34,56,76,23,89,123};
		int max=a[0];//12
		for(int i=1;i<a.length;i++)
		{
			if(a[i]>max)//a[34]>12
			{
				max=a[i];
			}
		}
		System.out.println(max);

	}

}
